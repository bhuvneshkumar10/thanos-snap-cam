# Snap Vanish — Thanos Snap Chrome Extension (Manifest V3)

Turn into dust particles and blow away on **Google Meet**, **Microsoft Teams**, and **Zoom on the Web** when you snap your fingers on camera—leaving behind a realistic AI-inpainted empty room while automatically muting your microphone. Snap your fingers a second time and the dust flies back together, you reappear, and your mic unmutes.

## Key Features
- **Real Finger-Snap Hand Tracking + Mic Click Confirmation**: Tracks raised-hand pinch & snap-release kinematics (ignoring typing in the lower frame and casual hand waves) and confirms with the high-frequency acoustic snap transient (`2.2–7.5 kHz`) from your microphone.
- **AI Empty-Room Background Inpainting**: Separates you from the background and continuously reconstructs a crisp, real empty room behind you using temporal clean-plate accumulation and multi-directional scanline/patch texture synthesis—never a blurry silhouette.
- **100% Local In-Browser Execution**: Runs entirely inside your browser via WebRTC `getUserMedia` stream interception, HTML5 Canvas, and WebAudio. Zero video or audio ever leaves your computer.
- **Full Popup Controls + Backup Shortcut**:
  - Master **On/Off** toggle
  - **Snap Now (Vanish / Reappear)** instant trigger button
  - **Backup Keyboard Shortcut**: `Alt + Shift + S`
  - **Snap Sensitivity** slider (`15% – 95%`)
  - **Dust Duration** slider (`1.0s – 5.0s`)
  - **Dust Drift Direction** selector (`Up & Right`, `Up & Left`, `Right`, `Upward`, `Swirling Vortex`)
  - **Built-in Webcam Test Studio**: Click **Test Webcam Studio ↗** in the popup to test your camera, room fill, and snap gesture anytime before joining a call.

## Quick Installation ("Load Unpacked")
1. **Unzip** `snap-vanish-extension.zip` to a folder on your computer (e.g., `snap-vanish`).
2. Open Google Chrome and navigate to `chrome://extensions/`.
3. Enable **Developer mode** using the toggle switch in the top-right corner.
4. Click **Load unpacked** in the top-left corner and select the unzipped `snap-vanish` folder.
5. Pin **Snap Vanish** from the puzzle-piece Extensions menu in your Chrome toolbar, then open **Google Meet** (`meet.google.com`), **Microsoft Teams** (`teams.microsoft.com`), or **Zoom Web** (`app.zoom.us`)—or click **Test Webcam Studio ↗** in the popup to try it immediately!
