/**
 * Snap Vanish — Background Service Worker (Manifest V3)
 * Coordinates default settings, extension badge status, keyboard shortcuts,
 * and messaging between the Popup UI and active meeting tabs.
 */

const DEFAULT_SETTINGS = {
  enabled: true,
  sensitivity: 68,          // 1 - 100 (higher = easier to trigger after hand snap kinematics)
  requireAudioClick: true,  // Require acoustic transient click confirmation from mic
  dustDuration: 2.6,        // Seconds (1.0 - 5.0)
  dustDirection: "up-right",// "up-right" | "up-left" | "right" | "up" | "vortex"
  autoMuteMic: true,        // Mute mic automatically when vanished, unmute on reappear
  showHudOverlay: true,     // Subtle status pill on local preview
  inpaintStrength: 85       // AI background fill refinement level
};

chrome.runtime.onInstalled.addListener(async () => {
  const stored = await chrome.storage.local.get(Object.keys(DEFAULT_SETTINGS));
  const merged = { ...DEFAULT_SETTINGS, ...stored };
  await chrome.storage.local.set(merged);
  updateBadge(merged.enabled, false);
});

function updateBadge(enabled, vanished) {
  if (!enabled) {
    chrome.action.setBadgeText({ text: "OFF" });
    chrome.action.setBadgeBackgroundColor({ color: "#475569" });
    return;
  }
  if (vanished) {
    chrome.action.setBadgeText({ text: "DUST" });
    chrome.action.setBadgeBackgroundColor({ color: "#d97706" });
  } else {
    chrome.action.setBadgeText({ text: "ON" });
    chrome.action.setBadgeBackgroundColor({ color: "#10b981" });
  }
}

async function broadcastToMeetingTabs(payload) {
  const tabs = await chrome.tabs.query({});
  for (const tab of tabs) {
    if (!tab.id) continue;
    try {
      await chrome.tabs.sendMessage(tab.id, payload);
    } catch (_) {
      // Tab does not host our content script
    }
  }
}

chrome.commands.onCommand.addListener(async (command) => {
  if (command === "trigger-snap") {
    await broadcastToMeetingTabs({ type: "SNAP_VANISH_COMMAND", action: "TOGGLE_SNAP", source: "shortcut" });
  } else if (command === "capture-clean-plate") {
    await broadcastToMeetingTabs({ type: "SNAP_VANISH_COMMAND", action: "RESET_BACKGROUND", source: "shortcut" });
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || !message.type) return false;

  if (message.type === "SNAP_VANISH_STATE_UPDATE") {
    chrome.storage.local.get(["enabled"], (res) => {
      updateBadge(res.enabled !== false, Boolean(message.vanished));
    });
    chrome.runtime.sendMessage(message).catch(() => {});
    sendResponse({ ok: true });
    return true;
  }

  if (message.type === "SNAP_VANISH_SETTINGS_CHANGED") {
    updateBadge(message.settings.enabled, Boolean(message.vanished));
    broadcastToMeetingTabs({
      type: "SNAP_VANISH_SETTINGS_UPDATE",
      settings: message.settings
    });
    sendResponse({ ok: true });
    return true;
  }

  if (message.type === "SNAP_VANISH_POPUP_ACTION") {
    broadcastToMeetingTabs({
      type: "SNAP_VANISH_COMMAND",
      action: message.action,
      payload: message.payload || {},
      source: "popup"
    });
    sendResponse({ ok: true });
    return true;
  }

  return false;
});
