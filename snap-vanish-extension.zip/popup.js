/**
 * Snap Vanish — Extension Popup Controller
 * Syncs user settings with `chrome.storage.local`, sends immediate commands to
 * active Google Meet / Microsoft Teams / Zoom Web tabs, and opens the built-in
 * Interactive Webcam Test Studio (`studio.html`).
 */

const DEFAULT_SETTINGS = {
  enabled: true,
  sensitivity: 68,
  requireAudioClick: true,
  dustDuration: 2.6,
  dustDirection: "up-right",
  autoMuteMic: true,
  showHudOverlay: true,
  inpaintStrength: 85
};

let currentSettings = { ...DEFAULT_SETTINGS };
let isVanished = false;

const els = {
  enabledToggle: document.getElementById("enabledToggle"),
  platformBadge: document.getElementById("platformBadge"),
  statusDot: document.getElementById("statusDot"),
  statusLabel: document.getElementById("statusLabel"),
  micPill: document.getElementById("micPill"),
  bgConfidenceVal: document.getElementById("bgConfidenceVal"),
  lastTriggerVal: document.getElementById("lastTriggerVal"),
  snapNowBtn: document.getElementById("snapNowBtn"),
  snapNowBtnText: document.getElementById("snapNowBtnText"),
  resetBgBtn: document.getElementById("resetBgBtn"),
  openStudioBtn: document.getElementById("openStudioBtn"),
  sensitivitySlider: document.getElementById("sensitivitySlider"),
  sensitivityVal: document.getElementById("sensitivityVal"),
  durationSlider: document.getElementById("durationSlider"),
  durationVal: document.getElementById("durationVal"),
  directionSelect: document.getElementById("directionSelect"),
  audioConfirmToggle: document.getElementById("audioConfirmToggle"),
  autoMuteToggle: document.getElementById("autoMuteToggle")
};

function renderSettingsUI() {
  els.enabledToggle.checked = Boolean(currentSettings.enabled);
  els.sensitivitySlider.value = currentSettings.sensitivity;
  els.sensitivityVal.textContent = `${currentSettings.sensitivity}%`;
  els.durationSlider.value = currentSettings.dustDuration;
  els.durationVal.textContent = `${Number(currentSettings.dustDuration).toFixed(1)}s`;
  els.directionSelect.value = currentSettings.dustDirection;
  els.audioConfirmToggle.checked = Boolean(currentSettings.requireAudioClick);
  els.autoMuteToggle.checked = Boolean(currentSettings.autoMuteMic);
}

function updateStateUI(state) {
  if (!state) return;
  isVanished = Boolean(state.vanished);

  if (state.platform) {
    els.platformBadge.textContent = `${state.platform} • 100% Local AI`;
  }

  if (!currentSettings.enabled) {
    els.statusDot.className = "status-dot";
    els.statusDot.style.background = "#64748b";
    els.statusLabel.textContent = "Disabled — Raw Camera Bypass";
    return;
  }

  els.statusDot.style.background = "";
  if (state.phase === "DISINTEGRATING") {
    els.statusDot.className = "status-dot vanished";
    els.statusLabel.textContent = "Disintegrating into Dust...";
  } else if (state.phase === "REAPPEARING") {
    els.statusDot.className = "status-dot";
    els.statusLabel.textContent = "Re-materializing from Dust...";
  } else if (isVanished) {
    els.statusDot.className = "status-dot vanished";
    els.statusLabel.textContent = "Vanished — Showing Empty Room";
  } else {
    els.statusDot.className = "status-dot";
    els.statusLabel.textContent = state.activeStream
      ? "Live — Watching for Finger Snap"
      : "Ready — Join Call or Open Studio";
  }

  if ( isVanished ) {
    els.snapNowBtn.classList.add("reappear-mode");
    els.snapNowBtnText.textContent = "Snap Now (Reappear & Unmute)";
  } else {
    els.snapNowBtn.classList.remove("reappear-mode");
    els.snapNowBtnText.textContent = "Snap Now (Vanish into Dust)";
  }

  if (state.micMuted) {
    els.micPill.textContent = "MIC MUTED";
    els.micPill.classList.add("muted");
  } else {
    els.micPill.textContent = "MIC LIVE";
    els.micPill.classList.remove("muted");
  }

  if (typeof state.bgConfidence === "number" && state.bgConfidence > 0) {
    els.bgConfidenceVal.textContent = `${state.bgConfidence}% Locked`;
  }
  if (state.lastTriggerReason) {
    els.lastTriggerVal.textContent = state.lastTriggerReason;
  }
}

async function saveAndBroadcastSettings() {
  await chrome.storage.local.set(currentSettings);
  chrome.runtime.sendMessage({
    type: "SNAP_VANISH_SETTINGS_CHANGED",
    settings: currentSettings,
    vanished: isVanished
  }).catch(() => {});
}

// Initialize popup
chrome.storage.local.get(Object.keys(DEFAULT_SETTINGS), (stored) => {
  currentSettings = { ...DEFAULT_SETTINGS, ...stored };
  renderSettingsUI();
});

// Query active tab status
chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
  const activeTab = tabs[0];
  if (activeTab && activeTab.id) {
    chrome.tabs.sendMessage(activeTab.id, { type: "SNAP_VANISH_GET_STATUS" }, (res) => {
      if (chrome.runtime.lastError || !res || !res.state) return;
      updateStateUI(res.state);
    });
  }
});

// Listen for real-time state updates while popup is open
chrome.runtime.onMessage.addListener((msg) => {
  if (msg && msg.type === "SNAP_VANISH_STATE_UPDATE") {
    updateStateUI(msg);
  }
});

// Event Listeners
els.enabledToggle.addEventListener("change", () => {
  currentSettings.enabled = els.enabledToggle.checked;
  saveAndBroadcastSettings();
  updateStateUI({ vanished: isVanished, activeStream: true });
});

els.sensitivitySlider.addEventListener("input", () => {
  currentSettings.sensitivity = Number(els.sensitivitySlider.value);
  els.sensitivityVal.textContent = `${currentSettings.sensitivity}%`;
  saveAndBroadcastSettings();
});

els.durationSlider.addEventListener("input", () => {
  currentSettings.dustDuration = Number(els.durationSlider.value);
  els.durationVal.textContent = `${currentSettings.dustDuration.toFixed(1)}s`;
  saveAndBroadcastSettings();
});

els.directionSelect.addEventListener("change", () => {
  currentSettings.dustDirection = els.directionSelect.value;
  saveAndBroadcastSettings();
});

els.audioConfirmToggle.addEventListener("change", () => {
  currentSettings.requireAudioClick = els.audioConfirmToggle.checked;
  saveAndBroadcastSettings();
});

els.autoMuteToggle.addEventListener("change", () => {
  currentSettings.autoMuteMic = els.autoMuteToggle.checked;
  saveAndBroadcastSettings();
});

els.snapNowBtn.addEventListener("click", () => {
  isVanished = !isVanished;
  updateStateUI({
    vanished: isVanished,
    phase: isVanished ? "DISINTEGRATING" : "REAPPEARING",
    micMuted: isVanished && currentSettings.autoMuteMic,
    lastTriggerReason: "Popup 'Snap Now' Button"
  });
  chrome.runtime.sendMessage({
    type: "SNAP_VANISH_POPUP_ACTION",
    action: "TOGGLE_SNAP"
  }).catch(() => {});
});

els.resetBgBtn.addEventListener("click", () => {
  els.lastTriggerVal.textContent = "Room AI Refreshed";
  chrome.runtime.sendMessage({
    type: "SNAP_VANISH_POPUP_ACTION",
    action: "RESET_BACKGROUND"
  }).catch(() => {});
});

els.openStudioBtn.addEventListener("click", () => {
  chrome.tabs.create({ url: chrome.runtime.getURL("studio.html") });
});
