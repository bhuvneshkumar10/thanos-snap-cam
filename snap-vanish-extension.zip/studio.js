/**
 * Snap Vanish — Built-in Interactive Webcam Test Studio
 */

const startCamBtn = document.getElementById("startCamBtn");
const previewVideo = document.getElementById("previewVideo");
const studioSnapBtn = document.getElementById("studioSnapBtn");
const studioCapturePlateBtn = document.getElementById("studioCapturePlateBtn");
const studioResetBgBtn = document.getElementById("studioResetBgBtn");

const phaseBadge = document.getElementById("phaseBadge");
const micBadge = document.getElementById("micBadge");
const handBadge = document.getElementById("handBadge");
const bgMeterLabel = document.getElementById("bgMeterLabel");
const bgMeterFill = document.getElementById("bgMeterFill");
const snapMeterLabel = document.getElementById("snapMeterLabel");
const snapMeterFill = document.getElementById("snapMeterFill");

async function startStudioStream() {
  try {
    const stream = await navigator.mediaDevices.getUserMedia({
      video: { width: { ideal: 1280 }, height: { ideal: 720 } },
      audio: true
    });
    previewVideo.srcObject = stream;
    startCamBtn.textContent = "Webcam Active ✓";
  } catch (err) {
    alert("Could not access webcam/microphone: " + err.message);
  }
}

startCamBtn.addEventListener("click", startStudioStream);

studioSnapBtn.addEventListener("click", () => {
  if (window.__snapVanishEngine) {
    window.__snapVanishEngine.triggerSnap("Studio Snap Button");
  }
});

studioCapturePlateBtn.addEventListener("click", () => {
  if (window.__snapVanishEngine) {
    window.__snapVanishEngine.captureCleanPlate();
  }
});

studioResetBgBtn.addEventListener("click", () => {
  if (window.__snapVanishEngine) {
    window.__snapVanishEngine.resetBackground();
  }
});

window.addEventListener("keydown", (e) => {
  if (e.altKey && e.shiftKey && (e.code === "KeyS" || e.key === "S" || e.key === "s")) {
    e.preventDefault();
    if (window.__snapVanishEngine) {
      window.__snapVanishEngine.triggerSnap("Keyboard Shortcut (Alt+Shift+S)");
    }
  }
});

window.addEventListener("message", (event) => {
  if (!event.data || event.data.source !== "SNAP_VANISH_PAGE") return;
  if (event.data.type === "STATE_CHANGE") {
    const st = event.data.state;
    phaseBadge.textContent = `PHASE: ${st.phase}`;
    micBadge.textContent = st.micMuted ? "MIC: AUTO-MUTED" : "MIC: UNMUTED";
    micBadge.className = st.micMuted ? "hud-pill red" : "hud-pill green";
    handBadge.textContent = st.handDetected ? "HAND TRACKER: RAISED HAND DETECTED" : "HAND TRACKER: SCANNING";
    bgMeterLabel.textContent = `${st.bgConfidence || 0}%`;
    bgMeterFill.style.width = `${st.bgConfidence || 0}%`;
    snapMeterLabel.textContent = `${st.snapReadiness || 0}%`;
    snapMeterFill.style.width = `${st.snapReadiness || 0}%`;
  }
});

// Auto-start camera when studio opens
startStudioStream();
