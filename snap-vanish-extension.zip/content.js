/**
 * Snap Vanish — Content Script Bridge
 * Injects `injected.js` at `document_start` into the MAIN page world so that
 * `navigator.mediaDevices.getUserMedia` is intercepted before Google Meet,
 * Microsoft Teams, or Zoom Web requests the webcam and microphone streams.
 */

(function initSnapVanishBridge() {
  if (window.__snapVanishBridgeLoaded) return;
  window.__snapVanishBridgeLoaded = true;

  let currentPageState = {
    activeStream: false,
    vanished: false,
    phase: "LIVE", // "LIVE" | "DISINTEGRATING" | "VANISHED" | "REAPPEARING"
    micMuted: false,
    bgConfidence: 0,
    handDetected: false,
    lastTriggerReason: "None",
    platform: detectPlatform()
  };

  function detectPlatform() {
    const host = location.hostname;
    if (host.includes("meet.google.com")) return "Google Meet";
    if (host.includes("teams.microsoft.com") || host.includes("teams.live.com")) return "Microsoft Teams";
    if (host.includes("zoom.us")) return "Zoom Web";
    return "Web Video";
  }

  // Inject MAIN world WebRTC interceptor immediately at document_start
  const script = document.createElement("script");
  script.src = chrome.runtime.getURL("injected.js");
  script.dataset.extensionBaseUrl = chrome.runtime.getURL("");
  (document.head || document.documentElement).appendChild(script);
  script.onload = () => {
    script.remove();
    syncStoredSettingsToPage();
  };

  function syncStoredSettingsToPage() {
    chrome.storage.local.get(null, (settings) => {
      window.postMessage(
        {
          source: "SNAP_VANISH_CONTENT",
          type: "SETTINGS_UPDATE",
          settings: settings || {}
        },
        "*"
      );
    });
  }

  // Listen for telemetry & state updates from MAIN world (`injected.js`)
  window.addEventListener("message", (event) => {
    if (event.source !== window || !event.data || event.data.source !== "SNAP_VANISH_PAGE") {
      return;
    }

    const msg = event.data;
    if (msg.type === "STATE_CHANGE") {
      currentPageState = {
        ...currentPageState,
        ...msg.state,
        platform: detectPlatform()
      };
      chrome.runtime.sendMessage({
        type: "SNAP_VANISH_STATE_UPDATE",
        ...currentPageState
      }).catch(() => {});
    } else if (msg.type === "REQUEST_INITIAL_SETTINGS") {
      syncStoredSettingsToPage();
    }
  });

  // Listen for commands & settings updates from Popup or Background service worker
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (!message || !message.type) return false;

    if (message.type === "SNAP_VANISH_SETTINGS_UPDATE") {
      window.postMessage(
        {
          source: "SNAP_VANISH_CONTENT",
          type: "SETTINGS_UPDATE",
          settings: message.settings
        },
        "*"
      );
      sendResponse({ ok: true });
      return true;
    }

    if (message.type === "SNAP_VANISH_COMMAND") {
      window.postMessage(
        {
          source: "SNAP_VANISH_CONTENT",
          type: "COMMAND",
          action: message.action,
          payload: message.payload || {},
          triggerSource: message.source || "popup"
        },
        "*"
      );
      sendResponse({ ok: true });
      return true;
    }

    if (message.type === "SNAP_VANISH_GET_STATUS") {
      sendResponse({ ok: true, state: currentPageState });
      return true;
    }

    return false;
  });

  // Backup keyboard listener directly inside meeting page (Alt+Shift+S)
  window.addEventListener(
    "keydown",
    (e) => {
      if (e.altKey && e.shiftKey && (e.code === "KeyS" || e.key === "S" || e.key === "s")) {
        e.preventDefault();
        window.postMessage(
          {
            source: "SNAP_VANISH_CONTENT",
            type: "COMMAND",
            action: "TOGGLE_SNAP",
            triggerSource: "shortcut"
          },
          "*"
        );
      } else if (e.altKey && e.shiftKey && (e.code === "KeyB" || e.key === "B" || e.key === "b")) {
        e.preventDefault();
        window.postMessage(
          {
            source: "SNAP_VANISH_CONTENT",
            type: "COMMAND",
            action: "RESET_BACKGROUND",
            triggerSource: "shortcut"
          },
          "*"
        );
      }
    },
    true
  );
})();
