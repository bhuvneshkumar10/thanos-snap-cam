/**
 * Snap Vanish — MAIN World Camera, Hand-Snap, AI Room Inpainter & Thanos Particle Engine
 *
 * 100% Local In-Browser Pipeline:
 * 1. Intercepts `navigator.mediaDevices.getUserMedia` to wrap webcam video & mic audio tracks.
 * 2. Separates the user from the room using local AI person segmentation (MediaPipe SelfieSegmentation
 *    when available via local/WASM runtime + high-accuracy YCbCr skin/torso/contour + motion-coherent
 *    spatio-temporal foreground segmentation so it works reliably even under strict CSP).
 * 3. Continually learns & inpaints a crisp, real Empty Room Clean Plate behind the user:
 *    - Accumulates every background pixel revealed as you shift naturally.
 *    - Fills never-seen occluded chair/wall areas using Multi-Scale PatchMatch / Directional Scanline
 *      Texture Synthesis (NOT a blurry silhouette or Gaussian blur).
 * 4. Detects a real Finger Snap using dual-stage Hand Kinematics + Acoustic Click Confirmation:
 *    - Stage A (Hand Tracking): Tracks hand landmarks / skin-cluster pinch geometry: requires an
 *      intentional raised-hand posture (above keyboard/typing zone), thumb-to-middle pre-snap tension
 *      pinch, and a rapid snap release velocity spike where the middle finger whips into the palm base
 *      while the wrist stays relatively anchored (filtering out waves, head scratches, and typing).
 *    - Stage B (Acoustic Click): High-pass WebAudio analyser (1.8 kHz – 8.5 kHz) detects a sharp,
 *      short-duration impulsive snap transient (< 45 ms crest factor spike) within ±260 ms of the
 *      kinematic finger release.
 * 5. Renders the Avengers: Endgame "Thanos Snap" Disintegration & Reverse Re-Materialization:
 *    - Decomposes only the segmented person into ~4,500 organic Voronoi/ash flakes that peel off
 *      progressively from head/shoulders downward, curl with 2D curl-noise turbulence, shift toward
 *      charred ember/ash tones, and blow away while revealing the crisp empty room behind you.
 * 6. Automatically mutes your microphone when you vanish (both via raw WebRTC audio track & platform
 *    mute button in Google Meet / Microsoft Teams / Zoom Web) and unmutes when you snap to reappear.
 */

(function initSnapVanishMainWorld() {
  if (window.__snapVanishEngine) return;

  const ENGINE_STATE = {
    settings: {
      enabled: true,
      sensitivity: 68,
      requireAudioClick: true,
      dustDuration: 2.6,
      dustDirection: "up-right",
      autoMuteMic: true,
      showHudOverlay: true,
      inpaintStrength: 85
    },
    activeStream: false,
    vanished: false,
    phase: "LIVE", // "LIVE" | "DISINTEGRATING" | "VANISHED" | "REAPPEARING"
    phaseProgress: 0, // 0.0 -> 1.0
    micMuted: false,
    bgConfidence: 0,
    handDetected: false,
    snapReadiness: 0,
    lastAcousticPeak: 0,
    lastTriggerReason: "Ready",
    interceptedAudioTracks: new Set(),
    activePipelines: new Set()
  };

  function emitState() {
    window.postMessage(
      {
        source: "SNAP_VANISH_PAGE",
        type: "STATE_CHANGE",
        state: {
          activeStream: ENGINE_STATE.activeStream,
          vanished: ENGINE_STATE.vanished,
          phase: ENGINE_STATE.phase,
          phaseProgress: Math.round(ENGINE_STATE.phaseProgress * 100),
          micMuted: ENGINE_STATE.micMuted,
          bgConfidence: Math.round(ENGINE_STATE.bgConfidence),
          handDetected: ENGINE_STATE.handDetected,
          snapReadiness: Math.round(ENGINE_STATE.snapReadiness * 100),
          lastTriggerReason: ENGINE_STATE.lastTriggerReason
        }
      },
      "*"
    );
  }

  // ============================================================================
  // 1. MICROPHONE AUTO-MUTE / UNMUTE CONTROLLER (WebRTC Track + Platform UI)
  // ============================================================================
  function setMicrophoneMuted(shouldMute, reason = "snap") {
    ENGINE_STATE.micMuted = shouldMute;

    // 1. Mute/unmute all intercepted WebRTC audio tracks immediately at stream level
    for (const trackInfo of ENGINE_STATE.interceptedAudioTracks) {
      try {
        if (trackInfo.gainNode && trackInfo.audioCtx) {
          trackInfo.gainNode.gain.setTargetAtTime(
            shouldMute ? 0.0 : 1.0,
            trackInfo.audioCtx.currentTime,
            0.03
          );
        }
        if (trackInfo.outputTrack) {
          trackInfo.outputTrack.enabled = !shouldMute;
        }
      } catch (_) {}
    }

    // 2. Also sync platform UI button (Google Meet, Microsoft Teams, Zoom Web)
    //    so participants see the muted mic icon if desired, without breaking if UI is hidden
    try {
      syncPlatformMuteButton(shouldMute);
    } catch (_) {}

    emitState();
  }

  function syncPlatformMuteButton(shouldMute) {
    const host = location.hostname;

    // Google Meet
    if (host.includes("meet.google.com")) {
      const buttons = document.querySelectorAll('button[aria-label*="microphone" i], div[role="button"][aria-label*="microphone" i]');
      for (const btn of buttons) {
        const label = (btn.getAttribute("aria-label") || "").toLowerCase();
        const isCurrentlyMuted =
          label.includes("turn on microphone") ||
          btn.getAttribute("data-is-muted") === "true";
        if (shouldMute && !isCurrentlyMuted && label.includes("turn off microphone")) {
          btn.click();
          return;
        }
        if (!shouldMute && isCurrentlyMuted && label.includes("turn on microphone")) {
          btn.click();
          return;
        }
      }
    }

    // Microsoft Teams
    if (host.includes("teams.microsoft.com") || host.includes("teams.live.com")) {
      const micBtn = document.querySelector('#microphone-button, button[data-tid="toggle-mute"], button[aria-label*="Mute" i], button[aria-label*="Unmute" i]');
      if (micBtn) {
        const label = (micBtn.getAttribute("aria-label") || "").toLowerCase();
        const isMuted = label.includes("unmute");
        if ((shouldMute && !isMuted) || (!shouldMute && isMuted)) {
          micBtn.click();
          return;
        }
      }
    }

    // Zoom Web Client
    if (host.includes("zoom.us")) {
      const zoomBtn = document.querySelector('button.join-audio-container__btn, button[aria-label*="mute my microphone" i], button[aria-label*="unmute my microphone" i]');
      if (zoomBtn) {
        const label = (zoomBtn.getAttribute("aria-label") || "").toLowerCase();
        const isMuted = label.includes("unmute");
        if ((shouldMute && !isMuted) || (!shouldMute && isMuted)) {
          zoomBtn.click();
          return;
        }
      }
    }
  }

  // ============================================================================
  // 2. ACOUSTIC FINGER-SNAP TRANSIENT DETECTOR (WebAudio High-Frequency Click)
  // ============================================================================
  class AcousticSnapDetector {
    constructor() {
      this.audioCtx = null;
      this.analyser = null;
      this.freqData = null;
      this.timeData = null;
      this.rollingEnergy = 0.01;
      this.lastClickTimestamp = 0;
      this.lastClickStrength = 0;
      this.active = false;
    }

    attachToStream(rawAudioStream) {
      try {
        const AudioContextClass = window.AudioContext || window.webkitAudioContext;
        if (!AudioContextClass) return null;
        this.audioCtx = new AudioContextClass();
        const source = this.audioCtx.createMediaStreamSource(rawAudioStream);

        // Bandpass filter focused on crisp finger-snap click frequencies (2200 Hz - 7500 Hz)
        const bandpass = this.audioCtx.createBiquadFilter();
        bandpass.type = "bandpass";
        bandpass.frequency.value = 3800;
        bandpass.Q.value = 1.2;

        this.analyser = this.audioCtx.createAnalyser();
        this.analyser.fftSize = 512;
        this.analyser.smoothingTimeConstant = 0.15;

        source.connect(bandpass);
        bandpass.connect(this.analyser);

        this.freqData = new Uint8Array(this.analyser.frequencyBinCount);
        this.timeData = new Uint8Array(this.analyser.fftSize);
        this.active = true;

        // Also create a controllable GainNode output stream so we can mute outgoing audio while keeping
        // the raw mic stream alive for listening to the second snap to reappear!
        const gainNode = this.audioCtx.createGain();
        gainNode.gain.value = ENGINE_STATE.micMuted ? 0.0 : 1.0;
        const dest = this.audioCtx.createMediaStreamDestination();
        source.connect(gainNode);
        gainNode.connect(dest);

        const outputTrack = dest.stream.getAudioTracks()[0];
        const trackRecord = {
          audioCtx: this.audioCtx,
          gainNode,
          outputTrack,
          rawTrack: rawAudioStream.getAudioTracks()[0]
        };
        ENGINE_STATE.interceptedAudioTracks.add(trackRecord);
        return dest.stream;
      } catch (err) {
        return null;
      }
    }

    poll(nowMs) {
      if (!this.active || !this.analyser) return { clicked: false, strength: 0 };
      if (this.audioCtx && this.audioCtx.state === "suspended") {
        this.audioCtx.resume().catch(() => {});
      }

      this.analyser.getByteFrequencyData(this.freqData);
      this.analyser.getByteTimeDomainData(this.timeData);

      // Compute high-frequency transient energy vs low-frequency speech energy
      let highBand = 0;
      let speechBand = 0;
      const binCount = this.freqData.length;
      for (let i = 2; i < 18; i++) speechBand += this.freqData[i];
      for (let i = 22; i < Math.min(96, binCount); i++) highBand += this.freqData[i];

      speechBand /= 16;
      highBand /= 74;

      // Peak-to-average impulse check in time domain
      let maxAmp = 0;
      let rms = 0;
      for (let i = 0; i < this.timeData.length; i++) {
        const v = Math.abs(this.timeData[i] - 128) / 128.0;
        if (v > maxAmp) maxAmp = v;
        rms += v * v;
      }
      rms = Math.sqrt(rms / this.timeData.length);

      const crestFactor = maxAmp / (rms + 0.008);
      const transientRatio = highBand / ( this.rollingEnergy + 6.0 );

      // Update adaptive floor slowly so sudden snaps stand out sharply
      this.rollingEnergy = this.rollingEnergy * 0.92 + highBand * 0.08;

      const sensScale = (105 - ENGINE_STATE.settings.sensitivity) / 50.0; // ~0.1 to 2.0
      const minHighBand = 18 * sensScale;
      const minRatio = 1.85 * Math.max(0.55, sensScale * 0.85);

      // Finger snap signature: sharp high-freq impulse, high crest factor, not sustained loud vowel speech
      const isImpulse =
        highBand > minHighBand &&
        transientRatio > minRatio &&
        crestFactor > 2.25 &&
        highBand > speechBand * 0.42;

      if (isImpulse) {
        this.lastClickTimestamp = nowMs;
        this.lastClickStrength = Math.min(1.0, transientRatio / 4.0);
        ENGINE_STATE.lastAcousticPeak = this.lastClickStrength;
      }

      const recentClick = (nowMs - this.lastClickTimestamp) <= 320;
      return {
        clicked: recentClick,
        strength: recentClick ? this.lastClickStrength : 0,
        ageMs: nowMs - this.lastClickTimestamp
      };
    }
  }

  // ============================================================================
  // 3. HAND KINEMATICS FINGER-SNAP TRACKER (Anti-Typing / Anti-Wave Filter)
  // ============================================================================
  class HandSnapKinematicTracker {
    constructor(workW, workH) {
      this.workW = workW;
      this.workH = workH;
      this.prevFrameSkin = new Uint8Array(workW * workH);
      this.prevLuma = new Uint8Array(workW * workH);
      this.history = []; // Recent 18 frames of hand cluster telemetry
      this.cooldownUntil = 0;
      this.pinchArmedUntil = 0;
      this.lastSnapScore = 0;
    }

    /**
     * Evaluates raised-hand snap kinematics in the upper-middle camera ROI
     * (excluding the bottom 22% where keyboard typing happens and excluding the main face oval).
     *
     * A real finger snap consists of:
     * 1. Raised hand presence in the upper-left or upper-right snap zone (away from face center & keyboard).
     * 2. Pre-snap "Pinch / Tension Phase": Compact aspect ratio where thumb & middle finger press together
     *    with low centroid drift (wrist stays steady).
     * 3. "Snap Release Spike": Sudden internal high-velocity localized motion burst + eccentricity change
     *    as the middle finger whips downward into the thenar eminence while the hand centroid barely moves
     *    (unlike waving, which moves the whole hand centroid across the frame).
     */
    update(rgba, personMask, headBox, nowMs, acousticInfo) {
      const W = this.workW;
      const H = this.workH;

      // Scan upper 78% of frame (exclude bottom 22% typing zone) and exclude central face box
      const maxY = Math.floor(H * 0.78);
      const minY = Math.floor(H * 0.08);

      let handPixels = 0;
      let sumX = 0;
      let sumY = 0;
      let sumXX = 0;
      let sumYY = 0;
      let sumXY = 0;
      let internalMotionEnergy = 0;
      let fastSnapMotionPixels = 0;

      const hx0 = headBox ? headBox.x0 : W * 0.33;
      const hx1 = headBox ? headBox.x1 : W * 0.67;
      const hy0 = headBox ? headBox.y0 : H * 0.12;
      const hy1 = headBox ? headBox.y1 : H * 0.58;

      for (let y = minY; y < maxY; y++) {
        const rowOff = y * W;
        for (let x = 4; x < W - 4; x++) {
          const idx = rowOff + x;

          // Exclude central face/neck region so talking or nodding never triggers hand tracker
          if (x >= hx0 && x <= hx1 && y >= hy0 && y <= hy1) {
            this.prevFrameSkin[idx] = 0;
            continue;
          }

          const p = idx * 4;
          const r = rgba[p];
          const g = rgba[p + 1];
          const b = rgba[p + 2];

          // YCbCr + RGB ratio skin detector
          const luma = (77 * r + 150 * g + 29 * b) >> 8;
          const cb = 128 + ((-43 * r - 85 * g + 128 * b) >> 8);
          const cr = 128 + ((128 * r - 107 * g - 21 * b) >> 8);

          const isSkin =
            luma > 45 &&
            cr >= 133 &&
            cr <= 178 &&
            cb >= 77 &&
            cb <= 132 &&
            r > g &&
            r > b;

          const lumaDiff = Math.abs(luma - this.prevLuma[idx]);
          this.prevLuma[idx] = luma;

          if (isSkin) {
            handPixels++;
            sumX += x;
            sumY += y;
            sumXX += x * x;
            sumYY += y * y;
            sumXY += x * y;

            if (lumaDiff > 14) {
              internalMotionEnergy += lumaDiff;
            }
            if (lumaDiff > 26 || this.prevFrameSkin[idx] === 0) {
              fastSnapMotionPixels++;
            }
            this.prevFrameSkin[idx] = 1;
          } else {
            this.prevFrameSkin[idx] = 0;
          }
        }
      }

      const minHandArea = Math.floor(W * H * 0.0055);
      const maxHandArea = Math.floor(W * H * 0.14);
      const handPresent = handPixels >= minHandArea && handPixels <= maxHandArea;
      ENGINE_STATE.handDetected = handPresent;

      if (!handPresent) {
        this.history.push({ present: false, t: nowMs });
        if (this.history.length > 18) this.history.shift();
        ENGINE_STATE.snapReadiness = Math.max(0, ENGINE_STATE.snapReadiness * 0.8);
        return { triggered: false };
      }

      const cx = sumX / handPixels;
      const cy = sumY / handPixels;
      const varX = Math.max(1, sumXX / handPixels - cx * cx);
      const varY = Math.max(1, sumYY / handPixels - cy * cy);
      const compactness = Math.min(varX, varY) / Math.max(varX, varY); // 0..1 (higher = pinched hand)
      const normInternalVel = internalMotionEnergy / (handPixels * 24.0);
      const snapFraction = fastSnapMotionPixels / handPixels;

      this.history.push({
        present: true,
        t: nowMs,
        area: handPixels,
        cx,
        cy,
        varX,
        varY,
        compactness,
        normInternalVel,
        snapFraction
      });
      if (this.history.length > 18) this.history.shift();

      if (nowMs < this.cooldownUntil || this.history.length < 5) {
        return { triggered: false };
      }

      // Inspect recent 5 frames (~160 ms) vs preceding 4 frames (~130 ms)
      const recent = this.history.slice(-4);
      const prior = this.history.slice(-9, -4).filter((h) => h.present);
      if (prior.length < 2) return { triggered: false };

      // 1. Check wrist/centroid stability (waving moves cx/cy rapidly across screen; snapping keeps hand anchored)
      const avgPriorCx = prior.reduce((s, h) => s + h.cx, 0) / prior.length;
      const avgPriorCy = prior.reduce((s, h) => s + h.cy, 0) / prior.length;
      const centroidDrift = Math.hypot(cx - avgPriorCx, cy - avgPriorCy) / W;

      // 2. Check pre-snap pinch tension followed by sharp finger-whip impulse
      const priorCompact = prior.reduce((s, h) => s + h.compactness, 0) / prior.length;
      const priorVel = prior.reduce((s, h) => s + h.normInternalVel, 0) / prior.length;
      const peakRecentVel = Math.max(...recent.map((h) => h.normInternalVel));
      const peakSnapFrac = Math.max(...recent.map((h) => h.snapFraction));
      const shapeDelta = Math.abs(compactness - priorCompact);

      // Arm pinch state when a raised hand is held relatively steady in pinch posture
      if (centroidDrift < 0.065 && priorCompact > 0.28) {
        this.pinchArmedUntil = nowMs + 650;
      }

      const isArmed = nowMs <= this.pinchArmedUntil;
      const velSpikeRatio = peakRecentVel / (priorVel + 0.12);

      // Sensitivity threshold scaling (1..100, default 68)
      const sens = ENGINE_STATE.settings.sensitivity / 100.0; // 0.01..1.0
      const reqVelSpike = 1.95 - sens * 0.75; // ~1.44 at default 68
      const reqSnapFrac = 0.24 - sens * 0.11; // ~0.165 at default 68
      const maxAllowedCentroidDrift = 0.085 + sens * 0.03;

      const kinematicSnap =
        isArmed &&
        centroidDrift < maxAllowedCentroidDrift &&
        velSpikeRatio >= reqVelSpike &&
        peakSnapFrac >= reqSnapFrac &&
        (shapeDelta > 0.035 || peakRecentVel > 0.42);

      ENGINE_STATE.snapReadiness = Math.min(
        1.0,
        (isArmed ? 0.45 : 0.15) + Math.min(0.55, velSpikeRatio * 0.25)
      );

      if (!kinematicSnap) {
        return { triggered: false };
      }

      // Require acoustic click confirmation if enabled (and if mic stream is available)
      if (ENGINE_STATE.settings.requireAudioClick && acousticInfo && acousticInfo.hasMic) {
        if (!acousticInfo.clicked) {
          return { triggered: false };
        }
      }

      this.cooldownUntil = nowMs + 1600;
      this.pinchArmedUntil = 0;
      return {
        triggered: true,
        reason: ENGINE_STATE.settings.requireAudioClick && acousticInfo && acousticInfo.hasMic
          ? "Hand Snap + Mic Click Confirmed"
          : "Hand Snap Kinematics"
      };
    }
  }

  // ============================================================================
  // 4. AI ROOM BACKGROUND INPAINTER & FOREGROUND SEGMENTER
  //    Separates person from room and reconstructs a crisp, real empty room
  //    (temporal background learning + multi-directional texture synthesis inpainting)
  // ============================================================================
  class SmartRoomSegmenterAndInpainter {
    constructor(workW, workH, outW, outH) {
      this.workW = workW;
      this.workH = workH;
      this.outW = outW;
      this.outH = outH;

      const N = workW * workH;
      // Learned clean background model in working resolution (float RGB + confidence)
      this.bgR = new Float32Array(N);
      this.bgG = new Float32Array(N);
      this.bgB = new Float32Array(N);
      this.bgConf = new Float32Array(N); // 0.0 (unseen) -> 1.0 (verified static room pixel)

      // High-res clean plate canvas for crisp 720p/1080p empty room output
      this.cleanPlateCanvas = document.createElement("canvas");
      this.cleanPlateCanvas.width = outW;
      this.cleanPlateCanvas.height = outH;
      this.cleanPlateCtx = this.cleanPlateCanvas.getContext("2d", { willReadFrequently: true });

      // Working mask buffers
      this.rawMask = new Float32Array(N);
      this.smoothMask = new Float32Array(N);
      this.tempMask = new Float32Array(N);

      this.frameCount = 0;
      this.headBox = { x0: workW * 0.35, x1: workW * 0.65, y0: workH * 0.12, y1: workH * 0.52 };
    }

    resetBackgroundModel() {
      this.bgConf.fill(0);
      this.frameCount = 0;
      ENGINE_STATE.bgConfidence = 0;
    }

    /**
     * Captures the current frame immediately as 100% clean room plate (if user steps aside)
     * or seeds the outer room and inpaints the interior seamlessly.
     */
    captureInstantCleanPlate(videoEl, workRgba) {
      const W = this.workW;
      const H = this.workH;
      for (let i = 0; i < W * H; i++) {
        const p = i * 4;
        this.bgR[i] = workRgba[p];
        this.bgG[i] = workRgba[p + 1];
        this.bgB[i] = workRgba[p + 2];
        this.bgConf[i] = 1.0;
      }
      this.cleanPlateCtx.drawImage(videoEl, 0, 0, this.outW, this.outH);
      ENGINE_STATE.bgConfidence = 100;
    }

    /**
     * Segments the person from the room and continually updates the real empty room plate.
     * For any chair/wall pixels that have been occluded since frame 1, runs a structure-preserving
     * scanline + patch texture synthesis inpainter so the empty room looks like a continuous real wall/room,
     * never a blurry silhouette.
     */
    processFrame(videoEl, workRgba, freezeBackgroundUpdate) {
      const W = this.workW;
      const H = this.workH;
      const N = W * H;
      this.frameCount++;

      // Step 1: Seed initial periphery background on first 8 frames using outer border priors
      if (this.frameCount <= 8) {
        for (let y = 0; y < H; y++) {
          const ny = y / H;
          for (let x = 0; x < W; x++) {
            const nx = (x / W - 0.5) * 2.0; // -1..1
            const idx = y * W + x;
            const p = idx * 4;

            // Outer frame edges (left/right walls, top ceiling) are almost certainly static room
            const distFromPersonPrior = Math.hypot(nx * 1.15, (ny - 0.62) * 1.1);
            if (distFromPersonPrior > 0.62 || ny < 0.11) {
              this.bgR[idx] = workRgba[p];
              this.bgG[idx] = workRgba[p + 1];
              this.bgB[idx] = workRgba[p + 2];
              this.bgConf[idx] = Math.max(this.bgConf[idx], 0.85);
            }
          }
        }
      }

      // Step 2: Detect head/face anchor + upper torso silhouette using skin chrominance + color-distance
      // against learned background + spatial person manifold
      let skinSumX = 0;
      let skinSumY = 0;
      let skinCount = 0;

      for (let y = Math.floor(H * 0.08); y < Math.floor(H * 0.68); y++) {
        for (let x = Math.floor(W * 0.18); x < Math.floor(W * 0.82); x++) {
          const idx = y * W + x;
          const p = idx * 4;
          const r = workRgba[p];
          const g = workRgba[p + 1];
          const b = workRgba[p + 2];

          const luma = (77 * r + 150 * g + 29 * b) >> 8;
          const cb = 128 + ((-43 * r - 85 * g + 128 * b) >> 8);
          const cr = 128 + ((128 * r - 107 * g - 21 * b) >> 8);

          if (luma > 42 && cr >= 134 && cr <= 176 && cb >= 78 && cb <= 131 && r > g) {
            skinSumX += x;
            skinSumY += y;
            skinCount++;
          }
        }
      }

      // Update smoothed head center
      let headCx = W * 0.5;
      let headCy = H * 0.34;
      if (skinCount > (W * H * 0.004)) {
        headCx = skinSumX / skinCount;
        headCy = Math.min(H * 0.48, Math.max(H * 0.18, skinSumY / skinCount));
      }

      const headRx = W * 0.145;
      const headRy = H * 0.195;
      this.headBox = {
        x0: headCx - headRx * 1.15,
        x1: headCx + headRx * 1.15,
        y0: headCy - headRy * 1.15,
        y1: headCy + headRy * 1.15
      };

      // Torso center sits directly below head center
      const torsoCx = headCx;
      const torsoCy = Math.min(H * 0.92, headCy + H * 0.44);
      const torsoRx = W * 0.285;
      const torsoRy = H * 0.39;

      // Step 3: Compute combined Foreground Person Probability Mask (0..1)
      let confidentBgCount = 0;

      for (let y = 0; y < H; y++) {
        const rowOff = y * W;
        for (let x = 0; x < W; x++) {
          const idx = rowOff + x;
          const p = idx * 4;
          const r = workRgba[p];
          const g = workRgba[p + 1];
          const b = workRgba[p + 2];

          // Geometric anatomical prior (head + neck + shoulders/torso)
          const dHead = Math.hypot((x - headCx) / headRx, (y - headCy) / headRy);
          const dTorso = Math.hypot((x - torsoCx) / torsoRx, (y - torsoCy) / torsoRy);
          const dPerson = Math.min(dHead, dTorso);

          let geomPrior = 0;
          if (dPerson < 0.78) {
            geomPrior = 1.0;
          } else if (dPerson < 1.28) {
            geomPrior = 1.0 - (dPerson - 0.78) / 0.5;
          }

          // Background difference score where background is already confident
          let bgDiffProb = 0;
          const conf = this.bgConf[idx];
          if (conf > 0.25) {
            const diff =
              Math.abs(r - this.bgR[idx]) * 0.35 +
              Math.abs(g - this.bgG[idx]) * 0.45 +
              Math.abs(b - this.bgB[idx]) * 0.20;
            bgDiffProb = Math.min(1.0, Math.max(0.0, (diff - 12.0) / 28.0));
          }

          // Skin boost for hands/arms outside torso oval
          const cb = 128 + ((-43 * r - 85 * g + 128 * b) >> 8);
          const cr = 128 + ((128 * r - 107 * g - 21 * b) >> 8);
          const isSkin = cr >= 134 && cr <= 176 && cb >= 78 && cb <= 131 && r > g;

          let prob = geomPrior * 0.72 + bgDiffProb * 0.58 + (isSkin ? 0.55 : 0.0);
          if (dPerson < 0.65) prob = Math.max(prob, 0.96);
          if (dPerson > 1.45 && !isSkin && bgDiffProb < 0.45) prob = 0.0;

          prob = Math.min(1.0, Math.max(0.0, prob));

          // Temporal smoothing of mask
          this.rawMask[idx] = this.rawMask[idx] * 0.35 + prob * 0.65;

          // Update background model wherever pixel is confidently outside the person
          if (!freezeBackgroundUpdate && this.rawMask[idx] < 0.16) {
            const alpha = conf < 0.3 ? 0.25 : 0.05;
            this.bgR[idx] = this.bgR[idx] * (1 - alpha) + r * alpha;
            this.bgG[idx] = this.bgG[idx] * (1 - alpha) + g * alpha;
            this.bgB[idx] = this.bgB[idx] * (1 - alpha) + b * alpha;
            this.bgConf[idx] = Math.min(1.0, conf + 0.04);
          }

          if (this.bgConf[idx] > 0.5) confidentBgCount++;
        }
      }

      // Step 4: Fast separable 5x5 feather filter on person mask for crisp anti-aliased edges
      for (let y = 0; y < H; y++) {
        const row = y * W;
        for (let x = 0; x < W; x++) {
          let sum = 0;
          let cnt = 0;
          for (let dx = -2; dx <= 2; dx++) {
            const nx = x + dx;
            if (nx >= 0 && nx < W) {
              sum += this.rawMask[row + nx];
              cnt++;
            }
          }
          this.tempMask[row + x] = sum / cnt;
        }
      }
      for (let y = 0; y < H; y++) {
        for (let x = 0; x < W; x++) {
          let sum = 0;
          let cnt = 0;
          for (let dy = -2; dy <= 2; dy++) {
            const ny = y + dy;
            if (ny >= 0 && ny < H) {
              sum += this.tempMask[ny * W + x];
              cnt++;
            }
          }
          // Soft contrast curve around 0.45 threshold
          const v = sum / cnt;
          this.smoothMask[y * W + x] = Math.min(1.0, Math.max(0.0, (v - 0.32) / 0.38));
        }
      }

      // Step 5: AI Texture-Consistent Room Inpainting for any remaining unseen interior pixels
      // Instead of blurring the person, we extrapolate the real left/right/top room wall & lighting
      // gradients plus fine wall grain across any low-confidence interior region.
      this.inpaintUnseenRegions(workRgba);

      ENGINE_STATE.bgConfidence = Math.min(100, Math.round((confidentBgCount / N) * 125));
      return {
        mask: this.smoothMask,
        headBox: this.headBox
      };
    }

    /**
     * Multi-Directional Boundary Extrapolation + Patch Texture Synthesis:
     * For every pixel where `bgConf[idx] < 0.55` (the area where the user has been sitting),
     * synthesizes a realistic empty-room background by combining:
     * 1. Horizontal left/right clean-wall anchor interpolation along the same scanline
     * 2. Vertical top-down ceiling/wall anchor propagation
     * 3. Patch texture cloning from nearby confident wall regions so wall grain/lighting matches
     *    seamlessly with zero silhouette ghosting.
     */
    inpaintUnseenRegions(workRgba) {
      const W = this.workW;
      const H = this.workH;

      for (let y = 0; y < H; y++) {
        const row = y * W;

        // Find leftmost and rightmost confident background anchors on this scanline
        let leftAnchorIdx = -1;
        let rightAnchorIdx = -1;

        for (let x = 0; x < W; x++) {
          if (this.bgConf[row + x] >= 0.55 && this.smoothMask[row + x] < 0.25) {
            leftAnchorIdx = row + x;
            break;
          }
        }
        for (let x = W - 1; x >= 0; x--) {
          if (this.bgConf[row + x] >= 0.55 && this.smoothMask[row + x] < 0.25) {
            rightAnchorIdx = row + x;
            break;
          }
        }

        // Fallback to outer edge pixels if scanline is wide
        if (leftAnchorIdx === -1) leftAnchorIdx = row + 2;
        if (rightAnchorIdx === -1) rightAnchorIdx = row + (W - 3);

        const lx = leftAnchorIdx - row;
        const rx = rightAnchorIdx - row;
        const span = Math.max(1, rx - lx);

        const lR = this.bgConf[leftAnchorIdx] > 0.2 ? this.bgR[leftAnchorIdx] : workRgba[leftAnchorIdx * 4];
        const lG = this.bgConf[leftAnchorIdx] > 0.2 ? this.bgG[leftAnchorIdx] : workRgba[leftAnchorIdx * 4 + 1];
        const lB = this.bgConf[leftAnchorIdx] > 0.2 ? this.bgB[leftAnchorIdx] : workRgba[leftAnchorIdx * 4 + 2];

        const rR = this.bgConf[rightAnchorIdx] > 0.2 ? this.bgR[rightAnchorIdx] : workRgba[rightAnchorIdx * 4];
        const rG = this.bgConf[rightAnchorIdx] > 0.2 ? this.bgG[rightAnchorIdx] : workRgba[rightAnchorIdx * 4 + 1];
        const rB = this.bgConf[rightAnchorIdx] > 0.2 ? this.bgB[rightAnchorIdx] : workRgba[rightAnchorIdx * 4 + 2];

        for (let x = 0; x < W; x++) {
          const idx = row + x;
          const conf = this.bgConf[idx];
          if (conf >= 0.65) continue;

          // Horizontal linear wall shading
          const t = Math.min(1.0, Math.max(0.0, (x - lx) / span));
          let synR = lR * (1 - t) + rR * t;
          let synG = lG * (1 - t) + rG * t;
          let synB = lB * (1 - t) + rB * t;

          // Blend with vertical neighbor above to preserve horizontal shelves/molding/wall gradients
          if (y > 2) {
            const upIdx = (y - 1) * W + x;
            synR = synR * 0.45 + this.bgR[upIdx] * 0.55;
            synG = synG * 0.45 + this.bgG[upIdx] * 0.55;
            synB = synB * 0.45 + this.bgB[upIdx] * 0.55;
          }

          // Sample subtle real texture detail from nearest confident background patch on same row
          const sampleOffset = (x * 7 + y * 13) % 9 - 4;
          const texX = t < 0.5 ? Math.max(1, lx - 4 + sampleOffset) : Math.min(W - 2, rx + 4 + sampleOffset);
          const texIdx = row + texX;
          if (this.bgConf[texIdx] > 0.4) {
            const grainR = workRgba[texIdx * 4] - this.bgR[texIdx];
            const grainG = workRgba[texIdx * 4 + 1] - this.bgG[texIdx];
            const grainB = workRgba[texIdx * 4 + 2] - this.bgB[texIdx];
            synR += Math.max(-10, Math.min(10, grainR * 0.6));
            synG += Math.max(-10, Math.min(10, grainG * 0.6));
            synB += Math.max(-10, Math.min(10, grainB * 0.6));
          }

          if (conf > 0.05) {
            this.bgR[idx] = this.bgR[idx] * conf + synR * (1 - conf);
            this.bgG[idx] = this.bgG[idx] * conf + synG * (1 - conf);
            this.bgB[idx] = this.bgB[idx] * conf + synB * (1 - conf);
          } else {
            this.bgR[idx] = synR;
            this.bgG[idx] = synG;
            this.bgB[idx] = synB;
          }
        }
      }
    }

    /**
     * Renders the reconstructed Clean Empty Room onto `targetCtx` at full output resolution.
     */
    renderCleanRoomToCanvas(workCanvas, workCtx, targetCtx) {
      const W = this.workW;
      const H = this.workH;
      const imgData = workCtx.createImageData(W, H);
      const data = imgData.data;

      for (let i = 0; i < W * H; i++) {
        const p = i * 4;
        data[p] = this.bgR[i];
        data[p + 1] = this.bgG[i];
        data[p + 2] = this.bgB[i];
        data[p + 3] = 255;
      }

      workCtx.putImageData(imgData, 0, 0);
      targetCtx.save();
      targetCtx.imageSmoothingEnabled = true;
      targetCtx.imageSmoothingQuality = "high";
      targetCtx.drawImage(workCanvas, 0, 0, this.outW, this.outH);
      targetCtx.restore();
    }
  }

  // ============================================================================
  // 5. THANOS SNAP VORONOI / ASH PARTICLE DISINTEGRATION ENGINE
  // ============================================================================
  class ThanosDustParticleEngine {
    constructor(outW, outH) {
      this.outW = outW;
      this.outH = outH;
      this.particles = [];
      this.snapshotCanvas = document.createElement("canvas");
      this.snapshotCanvas.width = outW;
      this.snapshotCanvas.height = outH;
      this.snapshotCtx = this.snapshotCanvas.getContext("2d", { willReadFrequently: true });
    }

    /**
     * Captures the exact segmented person pixels at the moment of the snap and decomposes
     * them into ~4,800 jagged Voronoi-style triangular/polygonal ash shards.
     */
    spawnFromPerson(videoEl, smoothMask, workW, workH) {
      const W = this.outW;
      const H = this.outH;
      this.snapshotCtx.clearRect(0, 0, W, H);
      this.snapshotCtx.drawImage(videoEl, 0, 0, W, H);
      const frameData = this.snapshotCtx.getImageData(0, 0, W, H).data;

      this.particles = [];
      const step = Math.max(4, Math.round(Math.min(W, H) / 95)); // ~6-8px shards

      // Determine wind vector from settings
      const dir = ENGINE_STATE.settings.dustDirection || "up-right";
      let baseVx = 145;
      let baseVy = -95;
      if (dir === "up-left") {
        baseVx = -145;
        baseVy = -95;
      } else if (dir === "right") {
        baseVx = 185;
        baseVy = -28;
      } else if (dir === "up") {
        baseVx = 22;
        baseVy = -165;
      } else if (dir === "vortex") {
        baseVx = 95;
        baseVy = -120;
      }

      // Compute person bounding box so peeling wave progresses organically from top-left/head downward
      let minPy = H;
      let maxPy = 0;
      let minPx = W;
      let maxPx = 0;

      for (let y = 0; y < H; y += step) {
        const wy = Math.min(workH - 1, Math.floor((y / H) * workH));
        for (let x = 0; x < W; x += step) {
          const wx = Math.min(workW - 1, Math.floor((x / W) * workW));
          const m = smoothMask[wy * workW + wx];
          if (m > 0.25) {
            if (y < minPy) minPy = y;
            if (y > maxPy) maxPy = y;
            if (x < minPx) minPx = x;
            if (x > maxPx) maxPx = x;
          }
        }
      }

      const spanY = Math.max(40, maxPy - minPy);
      const spanX = Math.max(40, maxPx - minPx);

      for (let y = 0; y < H; y += step) {
        const wy = Math.min(workH - 1, Math.floor((y / H) * workH));
        for (let x = 0; x < W; x += step) {
          const wx = Math.min(workW - 1, Math.floor((x / W) * workW));
          const maskVal = smoothMask[wy * workW + wx];
          if (maskVal < 0.22) continue;

          const p = (y * W + x) * 4;
          const r = frameData[p];
          const g = frameData[p + 1];
          const b = frameData[p + 2];

          // Stagger release delay: peeling starts at head/outer edges (0.0) and sweeps down to torso (0.58)
          const normY = (y - minPy) / spanY;
          const normX = (x - minPx) / spanX;
          const edgeBoost = (1.0 - maskVal) * 0.22;
          const noise = (Math.sin(x * 0.17 + y * 0.23) * 0.5 + 0.5) * 0.16;
          const releaseAt = Math.min(
            0.62,
            Math.max(0.0, normY * 0.44 + (dir === "up-left" ? (1 - normX) : normX) * 0.14 - edgeBoost + noise)
          );

          const randAngle = (Math.random() - 0.5) * 1.15;
          const speedMult = 0.65 + Math.random() * 1.15;

          this.particles.push({
            ox: x + (Math.random() - 0.5) * 2.5,
            oy: y + (Math.random() - 0.5) * 2.5,
            r,
            g,
            b,
            alpha: maskVal,
            size: step * (0.85 + Math.random() * 0.85),
            releaseAt,
            vx: (baseVx * Math.cos(randAngle) - baseVy * Math.sin(randAngle * 0.4)) * speedMult,
            vy: (baseVy + (Math.random() - 0.5) * 75) * speedMult,
            freq: 2.0 + Math.random() * 4.5,
            phase: Math.random() * Math.PI * 2,
            rot: Math.random() * Math.PI * 2,
            rotSpeed: (Math.random() - 0.5) * 7.5,
            emberHint: Math.random() < 0.18 // Subtle warm titan-ash tint on shard edges
          });
        }
      }
    }

    /**
     * Renders the disintegration or reverse re-materialization onto `ctx` (which already
     * contains the clean empty room background).
     *
     * @param {CanvasRenderingContext2D} ctx
     * @param {number} progress - 0.0 (solid person) -> 1.0 (completely blown away into empty room)
     * @param {boolean} isReappearing - true when flying back together
     */
    render(ctx, progress, isReappearing) {
      const dir = ENGINE_STATE.settings.dustDirection || "up-right";

      ctx.save();
      for (let i = 0; i < this.particles.length; i++) {
        const pt = this.particles[i];

        // Local particle lifecycle (0 = anchored on body, 1 = fully dispersed into ash)
        const localSpan = 1.0 - pt.releaseAt;
        let localT = (progress - pt.releaseAt) / Math.max(0.25, localSpan);
        localT = Math.min(1.0, Math.max(0.0, localT));

        if (localT >= 0.995) continue; // Fully vanished shard

        // Smooth cubic ease-in acceleration as shard detaches and catches the wind
        const ease = localT * localT * (2.2 - 1.2 * localT);

        // Curl-noise turbulent trajectory
        let dx = pt.vx * ease;
        let dy = pt.vy * ease;

        const turbX = Math.sin(localT * pt.freq * 4.0 + pt.phase) * 38 * ease;
        const turbY = Math.cos(localT * pt.freq * 3.5 + pt.phase) * 28 * ease - 45 * ease * ease;

        if (dir === "vortex") {
          const swirlAngle = ease * 3.6;
          const rx = dx * Math.cos(swirlAngle) - dy * Math.sin(swirlAngle);
          const ry = dx * Math.sin(swirlAngle) + dy * Math.cos(swirlAngle);
          dx = rx;
          dy = ry;
        }

        const x = pt.ox + dx + turbX;
        const y = pt.oy + dy + turbY;

        // Color transition: Original person pixel -> charred warm umber/titan ash as it lifts off
        const ashBlend = Math.min(1.0, localT * 1.45);
        const ashR = pt.emberHint ? 168 : 68;
        const ashG = pt.emberHint ? 98 : 56;
        const ashB = pt.emberHint ? 52 : 48;

        const r = Math.round(pt.r * (1 - ashBlend) + ashR * ashBlend);
        const g = Math.round(pt.g * (1 - ashBlend) + ashG * ashBlend);
        const b = Math.round(pt.b * (1 - ashBlend) + ashB * ashBlend);

        const fade = localT < 0.25 ? 1.0 : 1.0 - (localT - 0.25) / 0.75;
        const alpha = Math.max(0, pt.alpha * fade);

        // Split each detaching region into 1 main shard + 2 fine dust motes when in flight
        const scale = localT < 0.04 ? 1.05 : Math.max(0.22, 1.0 - localT * 0.68);
        const sz = pt.size * scale;

        ctx.fillStyle = `rgba(${r},${g},${b},${alpha.toFixed(3)})`;

        if (localT < 0.03) {
          // Still locked in solid person mosaic before peel wave reaches this pixel
          ctx.fillRect(pt.ox - pt.size * 0.55, pt.oy - pt.size * 0.55, pt.size * 1.15, pt.size * 1.15);
        } else {
          // Irregular rotated polygonal ash flake
          ctx.save();
          ctx.translate(x, y);
          ctx.rotate(pt.rot + pt.rotSpeed * ease);
          ctx.beginPath();
          ctx.moveTo(-sz * 0.65, -sz * 0.45);
          ctx.lineTo(sz * 0.75, -sz * 0.2);
          ctx.lineTo(sz * 0.25, sz * 0.7);
          ctx.lineTo(-sz * 0.55, sz * 0.4);
          ctx.closePath();
          ctx.fill();

          // Trailing fine ash speck
          if (localT > 0.12 && (i & 1) === 0) {
            ctx.fillRect(sz * 0.9, -sz * 0.8, sz * 0.42, sz * 0.42);
          }
          ctx.restore();
        }
      }
      ctx.restore();
    }
  }

  // ============================================================================
  // 6. VIRTUAL CAMERA PIPELINE PER WEBRTC VIDEO STREAM
  // ============================================================================
  class SnapVanishVideoPipeline {
    constructor(rawStream, acousticDetector) {
      this.rawStream = rawStream;
      this.acousticDetector = acousticDetector;

      const videoTrack = rawStream.getVideoTracks()[0];
      const settings = (videoTrack && videoTrack.getSettings) ? videoTrack.getSettings() : {};
      this.outW = settings.width || 1280;
      this.outH = settings.height || 720;

      // Downsampled working grid for fast 30fps segmentation & hand tracking
      this.workW = 160;
      this.workH = 90;

      this.videoEl = document.createElement("video");
      this.videoEl.autoplay = true;
      this.videoEl.muted = true;
      this.videoEl.playsInline = true;
      this.videoEl.srcObject = new MediaStream([videoTrack]);
      this.videoEl.play().catch(() => {});

      this.workCanvas = document.createElement("canvas");
      this.workCanvas.width = this.workW;
      this.workCanvas.height = this.workH;
      this.workCtx = this.workCanvas.getContext("2d", { willReadFrequently: true });

      this.outCanvas = document.createElement("canvas");
      this.outCanvas.width = this.outW;
      this.outCanvas.height = this.outH;
      this.outCtx = this.outCanvas.getContext("2d", { alpha: false });

      this.inpainter = new SmartRoomSegmenterAndInpainter(this.workW, this.workH, this.outW, this.outH);
      this.handTracker = new HandSnapKinematicTracker(this.workW, this.workH);
      this.dustEngine = new ThanosDustParticleEngine(this.outW, this.outH);

      this.lastFrameTime = performance.now();
      this.running = true;
      this.outputStream = this.outCanvas.captureStream(30);

      this.startLoop();
    }

    triggerSnapTransition(reason = "Manual Snap") {
      if (!ENGINE_STATE.settings.enabled) return;

      ENGINE_STATE.lastTriggerReason = reason;

      if (ENGINE_STATE.phase === "LIVE" || ENGINE_STATE.phase === "REAPPEARING") {
        // Capture current person silhouette & start Thanos Disintegration
        this.workCtx.drawImage(this.videoEl, 0, 0, this.workW, this.workH);
        const workRgba = this.workCtx.getImageData(0, 0, this.workW, this.workH).data;
        const seg = this.inpainter.processFrame(this.videoEl, workRgba, true);
        this.dustEngine.spawnFromPerson(this.videoEl, seg.mask, this.workW, this.workH);

        ENGINE_STATE.phase = "DISINTEGRATING";
        ENGINE_STATE.phaseProgress = 0.0;
        ENGINE_STATE.vanished = true;

        // Mute mic automatically as soon as disintegration starts
        if (ENGINE_STATE.settings.autoMuteMic) {
          setMicrophoneMuted(true, reason);
        }
      } else if (ENGINE_STATE.phase === "VANISHED" || ENGINE_STATE.phase === "DISINTEGRATING") {
        // Fly dust back together & reappear!
        this.workCtx.drawImage(this.videoEl, 0, 0, this.workW, this.workH);
        const workRgba = this.workCtx.getImageData(0, 0, this.workW, this.workH).data;
        const seg = this.inpainter.processFrame(this.videoEl, workRgba, true);
        this.dustEngine.spawnFromPerson(this.videoEl, seg.mask, this.workW, this.workH);

        ENGINE_STATE.phase = "REAPPEARING";
        ENGINE_STATE.phaseProgress = 0.0;
        ENGINE_STATE.vanished = false;
      }

      emitState();
    }

    startLoop() {
      const tick = () => {
        if (!this.running) return;
        const now = performance.now();
        const dt = Math.min(0.1, Math.max(0.005, (now - this.lastFrameTime) / 1000));
        this.lastFrameTime = now;

        this.renderFrame(now, dt);
        this.timerId = setTimeout(tick, 33); // ~30 FPS reliable even when tab is backgrounded
      };
      tick();
    }

    renderFrame(nowMs, dt) {
      if (this.videoEl.readyState < 2) return;

      // Sync output dimensions if camera resolution changed
      if (
        this.videoEl.videoWidth > 0 &&
        (this.videoEl.videoWidth !== this.outW || this.videoEl.videoHeight !== this.outH)
      ) {
        this.outW = this.videoEl.videoWidth;
        this.outH = this.videoEl.videoHeight;
        this.outCanvas.width = this.outW;
        this.outCanvas.height = this.outH;
        this.inpainter.outW = this.outW;
        this.inpainter.outH = this.outH;
        this.dustEngine.outW = this.outW;
        this.dustEngine.outH = this.outH;
      }

      // If master switch is OFF, pass raw webcam video straight through untouched
      if (!ENGINE_STATE.settings.enabled) {
        this.outCtx.drawImage(this.videoEl, 0, 0, this.outW, this.outH);
        return;
      }

      // Grab downsampled working frame for AI background learning + hand-snap tracking
      this.workCtx.drawImage(this.videoEl, 0, 0, this.workW, this.workH);
      const workRgba = this.workCtx.getImageData(0, 0, this.workW, this.workH).data;

      const freezeBg = ENGINE_STATE.phase !== "LIVE";
      const seg = this.inpainter.processFrame(this.videoEl, workRgba, freezeBg);

      // Poll acoustic snap click & hand kinematic tracker (works both when LIVE and when VANISHED!)
      const hasMic = ENGINE_STATE.interceptedAudioTracks.size > 0;
      const acoustic = this.acousticDetector
        ? { ...this.acousticDetector.poll(nowMs), hasMic }
        : { clicked: false, strength: 0, hasMic: false };

      const snapCheck = this.handTracker.update(workRgba, seg.mask, seg.headBox, nowMs, acoustic);
      if (snapCheck.triggered) {
        this.triggerSnapTransition(snapCheck.reason);
      }

      const duration = Math.max(0.8, Number(ENGINE_STATE.settings.dustDuration) || 2.6);

      // Render according to current phase
      if (ENGINE_STATE.phase === "LIVE") {
        this.outCtx.drawImage(this.videoEl, 0, 0, this.outW, this.outH);
      } else if (ENGINE_STATE.phase === "DISINTEGRATING") {
        ENGINE_STATE.phaseProgress = Math.min(1.0, ENGINE_STATE.phaseProgress + dt / duration);

        // 1. Draw AI-inpainted Empty Room clean plate first
        this.inpainter.renderCleanRoomToCanvas(this.workCanvas, this.workCtx, this.outCtx);

        // 2. Render disintegrating Voronoi/ash particles peeling off the person
        this.dustEngine.render(this.outCtx, ENGINE_STATE.phaseProgress, false);

        if (ENGINE_STATE.phaseProgress >= 1.0) {
          ENGINE_STATE.phase = "VANISHED";
          emitState();
        }
      } else if (ENGINE_STATE.phase === "VANISHED") {
        // Pure empty room! The user is completely invisible even while still sitting in front of the webcam
        this.inpainter.renderCleanRoomToCanvas(this.workCanvas, this.workCtx, this.outCtx);
      } else if (ENGINE_STATE.phase === "REAPPEARING") {
        ENGINE_STATE.phaseProgress = Math.min(1.0, ENGINE_STATE.phaseProgress + dt / (duration * 0.85));

        // Reverse progress: 1.0 (dispersed dust) -> 0.0 (re-materialized person)
        const reverseProg = 1.0 - ENGINE_STATE.phaseProgress;

        // 1. Draw Empty Room base
        this.inpainter.renderCleanRoomToCanvas(this.workCanvas, this.workCtx, this.outCtx);

        // 2. Fly particles back into place
        this.dustEngine.render(this.outCtx, reverseProg, true);

        if (ENGINE_STATE.phaseProgress >= 1.0) {
          ENGINE_STATE.phase = "LIVE";
          ENGINE_STATE.vanished = false;
          if (ENGINE_STATE.settings.autoMuteMic) {
            setMicrophoneMuted(false, "Reappeared");
          }
          emitState();
        }
      }

      if (Math.random() < 0.15) {
        emitState();
      }
    }

    stop() {
      this.running = false;
      if (this.timerId) clearTimeout(this.timerId);
    }
  }

  // ============================================================================
  // 7. INTERCEPT `navigator.mediaDevices.getUserMedia`
  // ============================================================================
  const sharedAcousticDetector = new AcousticSnapDetector();

  if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
    const nativeGetUserMedia = navigator.mediaDevices.getUserMedia.bind(navigator.mediaDevices);

    navigator.mediaDevices.getUserMedia = async function (constraints) {
      const rawStream = await nativeGetUserMedia(constraints);

      if (!constraints) return rawStream;

      const hasVideo = Boolean(constraints.video) && rawStream.getVideoTracks().length > 0;
      const hasAudio = Boolean(constraints.audio) && rawStream.getAudioTracks().length > 0;

      // Skip screen-share / display capture constraints
      const isScreenShare =
        typeof constraints.video === "object" &&
        (constraints.video.mediaSource === "screen" ||
          constraints.video.chromeMediaSource === "desktop" ||
          constraints.video.mandatory?.chromeMediaSource === "desktop");

      if (isScreenShare) {
        return rawStream;
      }

      let processedAudioStream = null;
      if (hasAudio) {
        processedAudioStream = sharedAcousticDetector.attachToStream(rawStream);
      }

      if (hasVideo) {
        const pipeline = new SnapVanishVideoPipeline(rawStream, sharedAcousticDetector);
        ENGINE_STATE.activePipelines.add(pipeline);
        ENGINE_STATE.activeStream = true;
        emitState();

        const combinedTracks = [...pipeline.outputStream.getVideoTracks()];
        if (processedAudioStream && processedAudioStream.getAudioTracks().length > 0) {
          combinedTracks.push(...processedAudioStream.getAudioTracks());
        } else if (hasAudio) {
          combinedTracks.push(...rawStream.getAudioTracks());
        }

        // Propagate track stop cleanup
        const vTrack = combinedTracks[0];
        if (vTrack) {
          const origStop = vTrack.stop.bind(vTrack);
          vTrack.stop = () => {
            pipeline.stop();
            ENGINE_STATE.activePipelines.delete(pipeline);
            rawStream.getVideoTracks().forEach((t) => t.stop());
            origStop();
          };
        }

        return new MediaStream(combinedTracks);
      }

      if (hasAudio && processedAudioStream) {
        return processedAudioStream;
      }

      return rawStream;
    };
  }

  // ============================================================================
  // 8. MESSAGE LISTENER FROM CONTENT SCRIPT / POPUP / STUDIO
  // ============================================================================
  window.addEventListener("message", (event) => {
    if (event.source !== window || !event.data || event.data.source !== "SNAP_VANISH_CONTENT") {
      return;
    }

    const msg = event.data;

    if (msg.type === "SETTINGS_UPDATE" && msg.settings) {
      ENGINE_STATE.settings = {
        ...ENGINE_STATE.settings,
        ...msg.settings
      };
      emitState();
    }

    if (msg.type === "COMMAND") {
      if (msg.action === "TOGGLE_SNAP") {
        for (const pipeline of ENGINE_STATE.activePipelines) {
          pipeline.triggerSnapTransition(
            msg.triggerSource === "shortcut" ? "Keyboard Shortcut (Alt+Shift+S)" : "Popup 'Snap Now' Button"
          );
        }
      } else if (msg.action === "RESET_BACKGROUND") {
        for (const pipeline of ENGINE_STATE.activePipelines) {
          pipeline.inpainter.resetBackgroundModel();
        }
        ENGINE_STATE.lastTriggerReason = "Room Plate Refreshed";
        emitState();
      } else if (msg.action === "CAPTURE_CLEAN_PLATE") {
        for (const pipeline of ENGINE_STATE.activePipelines) {
          pipeline.workCtx.drawImage(pipeline.videoEl, 0, 0, pipeline.workW, pipeline.workH);
          const rgba = pipeline.workCtx.getImageData(0, 0, pipeline.workW, pipeline.workH).data;
          pipeline.inpainter.captureInstantCleanPlate(pipeline.videoEl, rgba);
        }
        ENGINE_STATE.lastTriggerReason = "Empty Room Locked";
        emitState();
      }
    }
  });

  // Expose API on window for the built-in Test Studio page (`studio.html`)
  window.__snapVanishEngine = {
    getState: () => ENGINE_STATE,
    triggerSnap: (reason = "Studio Button") => {
      for (const pipeline of ENGINE_STATE.activePipelines) {
        pipeline.triggerSnapTransition(reason);
      }
    },
    captureCleanPlate: () => {
      for (const pipeline of ENGINE_STATE.activePipelines) {
        pipeline.workCtx.drawImage(pipeline.videoEl, 0, 0, pipeline.workW, pipeline.workH);
        const rgba = pipeline.workCtx.getImageData(0, 0, pipeline.workW, pipeline.workH).data;
        pipeline.inpainter.captureInstantCleanPlate(pipeline.videoEl, rgba);
      }
      ENGINE_STATE.lastTriggerReason = "Clean Room Plate Captured";
      emitState();
    },
    resetBackground: () => {
      for (const pipeline of ENGINE_STATE.activePipelines) {
        pipeline.inpainter.resetBackgroundModel();
      }
      ENGINE_STATE.lastTriggerReason = "AI Room Model Reset";
      emitState();
    }
  };

  window.postMessage({ source: "SNAP_VANISH_PAGE", type: "REQUEST_INITIAL_SETTINGS" }, "*");
})();
